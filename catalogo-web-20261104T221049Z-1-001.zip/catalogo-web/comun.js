// Funciones compartidas por la página de clientes y la de vendedor
const ICON='<svg viewBox="0 0 64 64" aria-hidden="true"><path d="M22 6l-14 8-6 14 9 5 3-6v33h36V27l3 6 9-5-6-14-14-8c-1 5-5 8-10 8s-9-3-10-8z"/></svg>';
const $=s=>document.querySelector(s);
const esc=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money=p=>{const n=parseFloat(String(p).replace(/[^\d.]/g,''));return isNaN(n)?esc(p):'$'+n.toLocaleString('es-MX',{maximumFractionDigits:2})};
const uid=()=>Math.random().toString(36).slice(2,10)+Date.now().toString(36);
function toast(t){const d=document.createElement('div');d.className='toast';d.textContent=t;document.body.appendChild(d);setTimeout(()=>d.remove(),2600)}

// Convierte enlaces de Google Drive en enlaces de imagen directos
function imgUrl(u){
  u=String(u||'').trim();
  const m=u.match(/drive\.google\.com\/(?:file\/d\/|open\?id=|uc\?(?:export=\w+&)?id=)([\w-]+)/);
  return m?'https://lh3.googleusercontent.com/d/'+m[1]:u;
}

// Lector de CSV (soporta comillas y saltos de línea dentro de celdas)
function parseCSV(t){
  const rows=[];let row=[],f='',q=false;
  for(let i=0;i<t.length;i++){const c=t[i];
    if(q){if(c=='"'){if(t[i+1]=='"'){f+='"';i++}else q=false}else f+=c}
    else if(c=='"')q=true;else if(c==','){row.push(f);f=''}
    else if(c=='\n'||c=='\r'){if(c=='\r'&&t[i+1]=='\n')i++;row.push(f);rows.push(row);row=[];f=''}
    else f+=c}
  if(f||row.length){row.push(f);rows.push(row)}
  return rows.filter(r=>r.some(x=>x.trim()));
}
const norm=s=>s.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g,'').trim();
function productsFromCSV(text){
  const [h,...rows]=parseCSV(text);if(!h)return[];
  const idx=k=>h.findIndex(x=>norm(x).startsWith(k));
  const c={n:idx('nombre'),c:idx('categoria'),p:idx('precio'),y:idx('ano')>=0?idx('ano'):idx('anio'),d:idx('descripcion'),i:idx('imagen')};
  const g=(r,k)=>c[k]>=0?(r[c[k]]||'').trim():'';
  return rows.map((r,k)=>({id:'s'+k,name:g(r,'n'),category:g(r,'c'),price:g(r,'p'),year:g(r,'y'),desc:g(r,'d'),
    images:g(r,'i').split(/[|\n]/).map(imgUrl).filter(Boolean)})).filter(p=>p.name);
}
function contactItems(c){
  const out=[];
  if(c.whatsapp)out.push(['WhatsApp',c.whatsapp,'https://wa.me/'+c.whatsapp.replace(/\D/g,'')]);
  if(c.phone)out.push(['Teléfono',c.phone,'tel:'+c.phone.replace(/[^\d+]/g,'')]);
  if(c.email)out.push(['Correo',c.email,'mailto:'+c.email]);
  if(c.instagram){const h=c.instagram.replace(/^@/,'');out.push(['Instagram','@'+h,'https://instagram.com/'+encodeURIComponent(h)])}
  if(c.facebook)out.push(['Facebook',c.facebook,/^https?:/.test(c.facebook)?c.facebook:null]);
  if(c.address)out.push(['Dirección',c.address,null]);
  return out;
}
